package com.ega.bank.ega_bank_api.model;

public enum AccountType {
    SAVINGS,
    CHECKING
}
