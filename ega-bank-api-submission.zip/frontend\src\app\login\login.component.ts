import { Component } from '@angular/core';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  template: `
  <h3>Login</h3>
  <form (submit)="onSubmit($event)">
    <label>Username <input name="username" [(ngModel)]="username"></label><br>
    <label>Password <input name="password" type="password" [(ngModel)]="password"></label><br>
    <button type="submit">Login</button>
  </form>
  <p *ngIf="error" style="color:red">{{error}}</p>
  `
})
export class LoginComponent {
  username = '';
  password = '';
  error: string | null = null;
  constructor(private auth: AuthService) {}

  onSubmit(e: Event) {
    e.preventDefault();
    this.auth.login(this.username, this.password).subscribe({
      next: (res: any) => {
        if (res?.token) {
          this.auth.saveToken(res.token);
          window.alert('Login successful');
        } else {
          this.error = 'Invalid response from server';
        }
      },
      error: err => this.error = err?.error?.message || 'Login failed'
    });
  }
}
