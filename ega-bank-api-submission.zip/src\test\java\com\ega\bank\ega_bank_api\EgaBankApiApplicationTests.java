package com.ega.bank.ega_bank_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EgaBankApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
