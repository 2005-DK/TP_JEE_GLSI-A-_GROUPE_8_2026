import { Component, OnInit } from '@angular/core';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-accounts',
  template: `
  <h3>Accounts</h3>
  <div *ngIf="accounts?.length===0">No accounts found</div>
  <ul>
    <li *ngFor="let a of accounts">
      {{a.accountNumber}} - {{a.type}} - Balance: {{a.balance}}
      <button (click)="deposit(a.accountNumber)">Deposit</button>
      <button (click)="withdraw(a.accountNumber)">Withdraw</button>
    </li>
  </ul>
  `
})
export class AccountsComponent implements OnInit{
  accounts: any[] = [];
  constructor(private svc: AccountService) {}
  ngOnInit(): void {
    this.load();
  }
  load(){
    this.svc.getAccounts().subscribe({next: (res: any) => this.accounts = res, error: () => this.accounts = []});
  }
  deposit(acc: string){
    const amount = Number(prompt('Amount to deposit') || '0');
    if(amount>0){ this.svc.deposit(acc, amount).subscribe({next: ()=>this.load()}); }
  }
  withdraw(acc: string){
    const amount = Number(prompt('Amount to withdraw') || '0');
    if(amount>0){ this.svc.withdraw(acc, amount).subscribe({next: ()=>this.load(), error: e=>alert(e?.error?.message||'Error')}); }
  }
}
