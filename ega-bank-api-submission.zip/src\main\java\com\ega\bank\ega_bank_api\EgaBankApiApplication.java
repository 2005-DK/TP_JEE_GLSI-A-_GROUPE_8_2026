package com.ega.bank.ega_bank_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EgaBankApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EgaBankApiApplication.class, args);
	}

}
